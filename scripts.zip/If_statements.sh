#!/bin/bash

mynum=200

if (( $mynum == 200 ))
then
	echo "true"
else
	echo "false"
fi
