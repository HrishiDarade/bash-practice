#!/bin/bash

echo "so basically this is the bash file that use to run multiple commands at once by executing the one bash file"

echo "my current working directory is : "
pwd
