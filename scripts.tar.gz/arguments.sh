#!/bin/bash

echo "if you want to print the argument passed after the file we used the '\$@' "

echo "Arguments: $@"
